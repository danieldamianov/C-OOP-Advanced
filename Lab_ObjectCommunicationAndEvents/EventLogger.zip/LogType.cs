﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Heroes
{
    public enum LogType
    {
        ATTACK, MAGIC, TARGET, ERROR, EVENT
    }
}
