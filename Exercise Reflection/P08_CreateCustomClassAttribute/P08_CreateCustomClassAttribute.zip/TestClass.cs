﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P08_CreateCustomClassAttribute
{
    [CustomClass("Pesho",3, "Used for C# OOP Advanced Course - Enumerations and Attributes.",new string[] { "Pesho", "Svetlio"})]
    class TestClass
    {
    }
}
