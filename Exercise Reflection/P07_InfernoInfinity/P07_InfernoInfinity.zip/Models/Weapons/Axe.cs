﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_InfernoInfinity.Models.Weapons
{
    public class Axe : Weapon
    {
        public Axe(string name, string rarity) : base(name,5,10,4,rarity)
        { }

    }
}
