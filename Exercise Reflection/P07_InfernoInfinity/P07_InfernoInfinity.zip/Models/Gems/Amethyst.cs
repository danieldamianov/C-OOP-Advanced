﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_InfernoInfinity.Models.Gems
{
    public class Amethyst : Gem
    {
        public Amethyst(string gemClarity) : base(gemClarity ,2,8,4)
        {
        }
    }
}
