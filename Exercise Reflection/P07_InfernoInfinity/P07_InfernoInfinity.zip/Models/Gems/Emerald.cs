﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_InfernoInfinity.Models.Gems
{
    public class Emerald : Gem
    {
        public Emerald(string gemClarity) : base(gemClarity, 1, 4, 9)
        {
        }
    }
}
