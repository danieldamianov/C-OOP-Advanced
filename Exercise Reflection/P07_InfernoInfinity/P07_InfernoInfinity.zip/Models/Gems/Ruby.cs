﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P07_InfernoInfinity.Models.Gems
{
    public class Ruby : Gem
    {
        public Ruby(string gemClarity) : base(gemClarity, 7, 2, 5)
        {
        }
    }
}
