﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_TrafficLights
{
    public enum Lights
    {
        Red = 1,
        Green = 2,
        Yellow = 3
    }
}
