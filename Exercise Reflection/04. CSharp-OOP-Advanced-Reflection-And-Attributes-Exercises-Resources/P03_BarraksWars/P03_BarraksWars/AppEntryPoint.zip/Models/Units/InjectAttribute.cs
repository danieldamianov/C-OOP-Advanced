﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_BarraksWars.Models.Units
{
    public class InjectAttribute : Attribute
    {
    }
}
