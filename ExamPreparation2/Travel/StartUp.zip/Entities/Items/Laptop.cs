﻿namespace Travel.Entities.Items
{
	public class Laptop : Item
	{
		public Laptop()
			: base(3000)
		{
		}
	}
}