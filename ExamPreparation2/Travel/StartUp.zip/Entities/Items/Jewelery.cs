﻿namespace Travel.Entities.Items
{
	public class Jewelery : Item
	{
		public Jewelery()
			: base(300)
		{
		}
	}
}