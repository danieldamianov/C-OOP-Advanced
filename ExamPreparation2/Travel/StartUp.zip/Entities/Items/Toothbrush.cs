﻿namespace Travel.Entities.Items
{
	public class Toothbrush : Item
	{
		public Toothbrush()
			: base(3)
		{
		}
	}
}