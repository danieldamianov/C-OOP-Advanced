﻿using System;
using System.Collections.Generic;
using System.Text;

public class Creature
{
    public int CreatureField;

    public int CreatureProperty { get; set; }

    public void CreatureMethod()
    {

    }
}


public class Human : Creature
{
    public int HumanField;

    public int HumanProperty { get; set; }

    public void HumanMethod()
    {

    }
}

public class Worker : Human
{
    public int WorkerField;

    public int WorkerProperty { get; set; }

    public void WorkerMethod()
    {

    }
}
